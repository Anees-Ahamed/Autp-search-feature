"use strict";
/**
 * 
 * This file is a set of general data that will be used by the Templates,
 * you can add any data to this file and it will be added to the task runner.
 *  
 */

module.exports = {

    "title": "Web Starter Template"

};